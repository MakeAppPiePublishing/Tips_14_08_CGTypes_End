///Core Graphics Types


import CoreGraphics


// CGFloat
var myX:CGFloat = 100.0 //could be double or single precision
var myIntY = 121
var myY = CGFloat(myIntY)

myY = 0.75 * myX
myY += 46

myY == myX
















// CGPoint
var point = CGPoint()
var point2 = CGPoint(x: myX, y: myY) //can be CGFloat, Int or Double

point.x = 10
point.x += myX
point.y = myY * 1.75

point = CGPoint.zero

point == point2













// CGSize
var size = CGSize()
var size1 = CGSize(width: 30, height: 60)

size1.width *= 20
size1.height = size1.width / 2.0

size == size1


















// CGRect

var rect0 = CGRect()
var rect = CGRect(origin: point, size: size1)
rect = CGRect(x: 10, y: 10, width: 200, height: 300)

rect.minX
rect.maxX
rect.midX

rect.minY
rect.maxY
rect.midY

var rect2 = CGRect()
rect2.size = size1

rect.contains(point)
rect.contains(rect)

rect.intersects(rect2)
rect.intersection(rect2)

rect.divided(atDistance: 20, from: .minXEdge).slice
rect
